Run the executable 'LocTranslationPercentage.exe' from within the current directory in a command prompt and specify the complete path to the folder containing the translated XMLs as an argument.

For example,
c:\dev\slk> LocTranslationPercentage.exe "C:\localization\slk\1092"

This will generate a text file in the specified localization folder with the translation percentage.

